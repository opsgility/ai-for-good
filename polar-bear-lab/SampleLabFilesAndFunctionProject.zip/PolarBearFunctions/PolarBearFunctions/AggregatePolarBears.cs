using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Text;
using Microsoft.WindowsAzure.Storage;
using PolarBearFunctions.Models;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace PolarBearFunctions
{
    public static class AggregatePolarBears
    {
        [FunctionName("AggregatePolarBears")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ExecutionContext context,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            try
            {
                string body = "";
                using (var reader = new StreamReader(req.Body))
                {
                    body = await reader.ReadToEndAsync();
                }
                var cpds = JsonConvert.DeserializeObject<List<CameraPhotoDetails>>(body);
                var cpdInput = new CameraPhotoDetailsInput() {
                    CapturedPhotos = cpds
                };
                var config = new ConfigurationBuilder()
                    .SetBasePath(context.FunctionAppDirectory)
                    .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables()
                    .Build();

                var storageConnectionString = config["StorageConnectionString"];
                var storageAccountName = config["StorageAccountName"];
                var containerName = config["StorageContainerName"];
                var storageAccount = CloudStorageAccount.Parse(storageConnectionString);
                var blobClient = storageAccount.CreateCloudBlobClient();
                var container = blobClient.GetContainerReference(containerName);
                var dbServer = config["DatabaseServer"];
                var dbName = config["DatabaseName"];
                var dbUser = config["DatabaseUserName"];
                var dbPWD = config["DatabasePassword"];

                foreach (var p in cpdInput.CapturedPhotos)
                {
                    log.LogInformation($"deviceId: {p.deviceId}");
                    log.LogInformation($"latitude: {p.latitude}");
                    log.LogInformation($"longitude: {p.longitude}");
                    p.blobName = p.url.Substring(p.url.LastIndexOf("/") + 1);
                    log.LogInformation($"blobName: {p.blobName}");
                    log.LogInformation($"timestamp: {p.timestamp}");
                    log.LogInformation($"url: {p.url}");

                    var blob = container.GetBlockBlobReference(p.blobName);
                    SharedAccessBlobPolicy adHocPolicy = new SharedAccessBlobPolicy()
                    {
                        SharedAccessExpiryTime = DateTime.UtcNow.AddMinutes(15),
                        Permissions = SharedAccessBlobPermissions.Read
                    };
                    // Generate the shared access signature on the container, setting the constraints directly on the signature.
                    var sasBlobToken = blob.GetSharedAccessSignature(adHocPolicy);
                    var blobUri = $"{p.url}{sasBlobToken}";
                    var document = $"\"url\":\"{blobUri}\"";
                    var jsonBody = string.Format("{0}{1}{2}", "{", document, "}");

                    log.LogInformation($"SAS for blob Token (ad hoc) created!");

                    var predictionKey = config["VisionURLKey"];
                    var predictionUrl = config["VisionURL"];

                    double threshold = 0.8;
                    bool isPolarBear = false;
                    VisionResult vr;
                    log.LogInformation($"Starting Vision Check...");
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Add("Prediction-Key", predictionKey);
                        var data = new StringContent(jsonBody, Encoding.UTF8, "application/json");

                        var result = await client.PostAsync(predictionUrl, data);
                        var resultBody = await result.Content.ReadAsStringAsync();

                        vr = JsonConvert.DeserializeObject<VisionResult>(resultBody);
                        var probability = vr?.predictions?.Find(p => p.tagName.Equals("polar bear", StringComparison.OrdinalIgnoreCase))?.probability;
                        isPolarBear = probability != null && probability > threshold;
                    }

                    log.LogInformation($"Vision Check Completed...");

                    if (isPolarBear)
                    {
                        log.LogInformation("Polar bear found, starting db entry...");
                        //write to database..
                        var cnstr =$"server={dbServer};Initial Catalog={dbName};uid={dbUser};pwd={dbPWD};Encrypt=True;";
                        var builder = new SqlConnectionStringBuilder();
                        builder.DataSource = dbServer;
                        builder.UserID = dbUser;
                        builder.Password = dbPWD;
                        builder.InitialCatalog = dbName;

                        using (var connection = new SqlConnection(builder.ConnectionString))
                        { 
                            var query = $"INSERT INTO dbo.PolarBears (CameraID, Latitude, Longitude, URL, Timestamp, IsPolarBear)" +
                                                $"VALUES('{p.deviceId}', {p.latitude}, {p.longitude}, '{p.url}', '{p.timestamp}', 1)";
                           
                            using (var cmd = new SqlCommand(query, connection))
                            {
                                connection.Open();
                                await cmd.ExecuteNonQueryAsync();
                                log.LogInformation("Polar bear data recoreded successfully");
                            }
                        }

                        log.LogInformation($"Db Entry Completed....");
                    }
                }

            }
            catch (Exception ex)
            {
                log.LogError($"Bad stuff: {ex.Message}");
            }


            log.LogInformation("Completed");
            return new OkObjectResult("working");
        }
    }
}
