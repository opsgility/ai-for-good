﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PolarBearFunctions.Models
{
    class CameraPhotoDetailsInput
    {
        public List<CameraPhotoDetails> CapturedPhotos {get;set;}
    }
}
