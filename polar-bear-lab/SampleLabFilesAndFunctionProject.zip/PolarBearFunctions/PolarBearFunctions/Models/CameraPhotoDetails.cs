﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PolarBearFunctions.Models
{
    class CameraPhotoDetails
    {
        public string deviceId { get; set; }
        public double latitude { get; set; }
        public double longitude { get; set; }
        public string blobName { get; set; }
        public string url { get; set; }

        public string timestamp { get; set; }
    }
}
