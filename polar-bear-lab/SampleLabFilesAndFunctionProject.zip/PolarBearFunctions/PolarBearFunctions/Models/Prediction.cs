﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PolarBearFunctions.Models
{
    class Prediction
    {
        public double probability { get; set; }
        public string tagId { get; set; } 
        public string tagName { get; set; }
    }
}
